import sys
from antlr4 import *
from CalculadoraTrigonometricaLexer import CalculadoraTrigonometricaLexer
from CalculadoraTrigonometricaParser import CalculadoraTrigonometricaParser
import math

class CalculadoraTrigonometricaVisitor(ParseTreeVisitor):

    def visitExpr(self, ctx):
        funcion = ctx.func().getText()
        angulo = float(ctx.getChild(2).getText())  # Asegura que accedes al número correctamente
        print(f"Procesando: {funcion}({angulo})")  # Mensaje de depuración
        if funcion == "Sin":
            return math.sin(math.radians(angulo))
        elif funcion == "Cos":
            return math.cos(math.radians(angulo))
        elif funcion == "Tan":
            return math.tan(math.radians(angulo))
        else:
            print(f"Función desconocida: {funcion}")
            return None


def main(argv):
    if len(argv) < 2:
        print("Uso: python3 calculadora_trigonometrica.py <archivo de entrada>")
        return

    input_stream = FileStream(argv[1])
    lexer = CalculadoraTrigonometricaLexer(input_stream)
    stream = CommonTokenStream(lexer)
    parser = CalculadoraTrigonometricaParser(stream)
    tree = parser.expr()

    print(tree.toStringTree(recog=parser))  # Imprime el árbol de sintaxis


    visitor = CalculadoraTrigonometricaVisitor()
    result = visitor.visit(tree)

    if result is not None:
        print(f"Resultado: {result:.2f}")
    else:
        print("Error: No se pudo calcular el resultado.")

if __name__ == '__main__':
    main(sys.argv)
