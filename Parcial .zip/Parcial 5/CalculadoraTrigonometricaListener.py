# Generated from CalculadoraTrigonometrica.g4 by ANTLR 4.13.0
from antlr4 import *
if "." in __name__:
    from .CalculadoraTrigonometricaParser import CalculadoraTrigonometricaParser
else:
    from CalculadoraTrigonometricaParser import CalculadoraTrigonometricaParser

# This class defines a complete listener for a parse tree produced by CalculadoraTrigonometricaParser.
class CalculadoraTrigonometricaListener(ParseTreeListener):

    # Enter a parse tree produced by CalculadoraTrigonometricaParser#expr.
    def enterExpr(self, ctx:CalculadoraTrigonometricaParser.ExprContext):
        pass

    # Exit a parse tree produced by CalculadoraTrigonometricaParser#expr.
    def exitExpr(self, ctx:CalculadoraTrigonometricaParser.ExprContext):
        pass


    # Enter a parse tree produced by CalculadoraTrigonometricaParser#func.
    def enterFunc(self, ctx:CalculadoraTrigonometricaParser.FuncContext):
        pass

    # Exit a parse tree produced by CalculadoraTrigonometricaParser#func.
    def exitFunc(self, ctx:CalculadoraTrigonometricaParser.FuncContext):
        pass



del CalculadoraTrigonometricaParser