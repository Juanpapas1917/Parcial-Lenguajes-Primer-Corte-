def factorial(n):
    if n == 0:
        return 1
    else:
        return n * factorial(n - 1)

num = 20  # Cambia este número para probar diferentes casos
print(f"Factorial de {num} es {factorial(num)}")
