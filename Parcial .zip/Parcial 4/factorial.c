#include <stdio.h>

long long factorial(int n) {
    if (n == 0)
        return 1;
    else
        return n * factorial(n - 1);
}

int main() {
    int num = 20;  // Cambia este número para probar diferentes casos
    printf("Factorial de %d es %lld\n", num, factorial(num));
    return 0;
}
